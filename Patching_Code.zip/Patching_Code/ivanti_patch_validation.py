#!/usr/bin/env python

from lib.base_action import BaseAction

#API Request Module
import requests
from requests_ntlm import HttpNtlmAuth

class Ivantipatchvalidation(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(Ivantipatchvalidation, self).__init__(config)

    def run(self, server, planned_start_date, planned_end_date):

         ivantiloglist = []
         patch_flag = "failed"
         statuscode = ''
         patches = ''
         
         headers = {'Accept': 'application/json','Content-type': 'application/json'}
         deployments_url = "https://amaxwin03.nttdsodev.net:3121/st/console/api/v1.0/patch/deployments/?OnOrAfter=2025-07-04T13:41:59.047Z"
         #print(deployments_url)
         deployments = requests.get(deployments_url, auth=HttpNtlmAuth('Sreedevi.AN@nttdsodev.net','Stackstorm@2026'), headers=headers, verify=False)
         deployments_json = deployments.json()['value']
         #print(deployments_json)
         for deployment in deployments_json:
             #print(deployment)
             deployment_id = deployment['id']
             #print(deployment_id)
             deployment_url = 'https://amaxwin03.nttdsodev.net:3121/st/console/api/v1.0/patch/deployments/'+ deployment_id +'/machines?name='+ server
             #print(deployment_url)
             deployment_data = requests.get(deployment_url, auth=HttpNtlmAuth('Sreedevi.AN@nttdsodev.net','Stackstorm@2026'), headers=headers, verify=False)
             #print(deployment_data.json())
             deploymentdatajson = deployment_data.json()
             patches = deploymentdatajson['value'][0]['patchStates']   

             result = {"API_status_code": 200, "Server_found": "true", "Patch_status_code": 200, "Installed_patches": patches, "patch_flag":"success"}
         return result
   
