# file: Import-IssuingCertificate.ps1
<#
.SYNOPSIS
 Imports the issuing certificate into the current users's certificate store.
#>
$derEncodedBytes = 'MIIDmjCCAoKgAwIBAgIQXyj7eAlnVpRGOnmfprDsEDANBgkqhkiG9w0BAQsFADBnMRowGAYDVQQDExFTVCBSb290IEF1dGhvcml0eTEZMBcGCgmSJomT8ixkARkWCUFtYXh3aW4wMzEZMBcGCgmSJomT8ixkARkWCW50dGRzb2RldjETMBEGCgmSJomT8ixkARkWA25ldDAeFw0yNTA2MDMxNjI5MDlaFw0zNTA2MDQxNjI5MDlaMGcxGjAYBgNVBAMTEVNUIFJvb3QgQXV0aG9yaXR5MRkwFwYKCZImiZPyLGQBGRYJQW1heHdpbjAzMRkwFwYKCZImiZPyLGQBGRYJbnR0ZHNvZGV2MRMwEQYKCZImiZPyLGQBGRYDbmV0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuQ/4/Iy2+yzTXazKAJp91UA2RToCZXoFAjZ06o4e026bsWZzxvyXUQgrMwVJvoMZ7xI1BTWW5FMTFBYnccHqbRqX9rYoH45akZVW0fA9pxsZ1/gUrHsjF0tL6EeNEZPPtm+3Jl9g90ifU6ivGu7UUFbSuAxf4mAhRPiFDXrGPpakcodhZlrzIf7JBDv311YpOFghYFX95yG8mKnjJi74TQYvBNxUqUDGY5WPbD73e37ECR5eeFfV1HkPzfBETE22ZbEA/LBOn72nIaVPyqWYmrLdQjeVDKzfIYUdqR/Ir5QxGfnU+UhOh0DVqcJgJoIMWQ8oMdpGIdUMKMmWDaF3NQIDAQABo0IwQDAdBgNVHQ4EFgQU/jrJiJsXk6f29GCymLc9GkBiXIYwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAYYwDQYJKoZIhvcNAQELBQADggEBAFeAWrAceD//71eZTb9iAmGTLGqssJcSPlnAperXB4kmAqzB4jJX2VHvdVTsdxeG5YnbNtQ07Xvzrqo84vaxQzwk1KO1ff3jwmQU9tngIJ9GO2GhANDMlmj0ocAnr0wVedrMImatn8/T9MKzEiFDCFokvoU4L5uZLF+BmvHz81fJlfft2diUaHPMKFuRzURLVfTt+ifi+nQRBm7qTIcmFHFbXA17z3y3wioYTtGWLVqQFqx6Qkrt9FekLDZvZS+Dfx/DlnDitTclVcx6DxwuhSzCmZcJpw3dKc8FDTzgAEIebKAkhoxS3DxI6rntBnaVX3C2CnNglPuHp8eT1FQbBiE='

$decodedBytes = [System.Convert]::FromBase64String($derEncodedBytes)
$isPS2 = $PSVersionTable.PSVersion.Major -eq 2
if($isPS2)
{
    [void][Reflection.Assembly]::LoadWithPartialName("System.Security") 
}
else
{
    Add-Type -AssemblyName "System.Security" > $null
}

try
{
    Push-Location 'Cert:\CurrentUser\Root'
    $certificateMissing = (Get-ChildItem | Where-Object { $_.Thumbprint -eq $iSeCIssuingCertificate.Thumbprint } ) -eq $null
    if($certificateMissing)
    {
        $iSeCIssuingCertificate = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 -ArgumentList @(,$decodedBytes)
        
        $store = Get-Item 'Cert:\CurrentUser\Root'
        $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadWrite)
        $store.Add($iSeCIssuingCertificate)
    }
}
finally
{
    Pop-Location

    if($store -ne $null)
    {
        $store.Close()
    }

    if(-not $isPS2)
    {
        if($iSeCIssuingCertificate -ne $null)
        {
            $iSeCIssuingCertificate.Dispose()
            $iSeCIssuingCertificate = $null
        }

        if($store -ne $null)
        {
            $store.Dispose()
            $store = $null
        }
    }
}