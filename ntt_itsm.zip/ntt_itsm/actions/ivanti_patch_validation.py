#!/usr/bin/env python

from lib.base_action import BaseAction

#API Request Module
import requests
from requests_ntlm import HttpNtlmAuth
import json
import ast

class Ivantipatchvalidation(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(Ivantipatchvalidation, self).__init__(config)

    def run(self, server, planned_start_date, planned_end_date,ivanti_server, ivanti_username,ivanti_password):

         ivantiloglist = []
         patch_flag = "failed"
         statuscode = ''
         patches = ''
         butlletinId = ''
         kb = ''
         product_name =''
         patchStates = ''
         patchState = ''
         deployments_json = ''
         deploymentdatajson = ''
         deployment_data = ''
         result = ''

         patches = patches + "\n\n -------------------- \n"
         headers = {'Accept': 'application/json','Content-type': 'application/json'}
         deployments_url = "https://amaxwin03.nttdsodev.net:3121/st/console/api/v1.0/patch/deployments/?OnOrAfter=2025-07-15T13:30:59.047Z"
         print(deployments_url)
         deployments = requests.get(deployments_url, auth=HttpNtlmAuth(ivanti_username, ivanti_password), headers=headers, verify=False)
         deployments_json = deployments.json()['value']

         for deployment in deployments_json:
             deployment_id = deployment['id']
             deployment_url = 'https://amaxwin03.nttdsodev.net:3121/st/console/api/v1.0/patch/deployments/'+ deployment_id +'/machines?name='+ server
             deployment_data = requests.get(deployment_url, auth=HttpNtlmAuth(ivanti_username, ivanti_password), headers=headers, verify=False)
             deploymentdatajson = deployment_data.json()
             patchStates = deploymentdatajson['value'][0]['patchStates']
             #print("patchStates: ",patchStates)
             
             for patchState in patchStates:
                 bulletinId = patchState['bulletinId']
                 kb = patchState['kb']
                 #print(bulletinId)
                 patch_details_url = 'https://amaxwin03.nttdsodev.net:3121/st/console/api/v1.0/patch/patchmetadata?kbs='+ kb + '&bulletinId=' + bulletinId
                 print(patch_details_url)
                 patch_details = deployment_data = requests.get(patch_details_url, auth=HttpNtlmAuth(ivanti_username, ivanti_password), headers=headers, verify=False)
                 patch_details = patch_details.json()
                 product_name = patch_details['value'][0]['bulletinTitle']
                 patch_type = patch_details['value'][0]['patchType']
                 patch_name = patch_details['value'][0]['name']
                 #print("Product Name ",product_name)
                 #print("PatchState",patchState)

             patches = patches + "\n Prodcut Name: " + product_name +  "\n Patch Type: " + patch_type +  "\n Patch Name: " + patch_name
             patches = patches + "\n -----------------------------------------------------------------" 
             #print(patches)
             result = {"API_status_code": 200, "Server_found": "true", "Patch_status_code": 200, "Installed_patches": patches, "patch_flag":"success"}
         return result
   
