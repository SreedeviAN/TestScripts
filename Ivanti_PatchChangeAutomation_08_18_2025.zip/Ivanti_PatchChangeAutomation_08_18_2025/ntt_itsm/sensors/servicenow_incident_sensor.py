#!/usr/bin/env python
# Copyright 2021 Encore Technologies
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# https://www.w3schools.com/python/trypython.asp?filename=demo_ref_string_split3
from st2reactor.sensor.base import PollingSensor
from st2client.models.keyvalue import KeyValuePair  # pylint: disable=no-name-in-module
import requests
import ast
import socket
from datetime import datetime
import os
from st2client.client import Client
import sys
import re
sys.path.append(os.path.dirname(os.path.realpath(__file__)) + '/../actions/lib')
import base_action

__all__ = [
    'ServiceNowIncidentSensor'
]


class ServiceNowIncidentSensor(PollingSensor):
    def __init__(self, sensor_service, config=None, poll_interval=None):
        super(ServiceNowIncidentSensor, self).__init__(sensor_service=sensor_service,
                                                       config=config,
                                                       poll_interval=poll_interval)
        self._logger = self._sensor_service.get_logger(__name__)
        self.base_action = base_action.BaseAction(config)

    def setup(self):
        self.sn_username = self._config['servicenow']['username']
        self.sn_password = self._config['servicenow']['password']
        self.sn_url = self._config['servicenow']['url']
        self.som_company_sys_id =  self.config['servicenow']['company_sys_id']
        self.servicenow_headers = {'Content-type': 'application/json',
                                   'Accept': 'application/json'}
        self.st2_fqdn = socket.getfqdn()
        st2_url = "https://{}/".format(self.st2_fqdn)
        self.st2_client = Client(base_url=st2_url)

    def poll(self):
        # Query for all active and open incidents
        self._logger.info('STARTED_INCIDENT_SENSOR_AT: {}'.format(datetime.now()))
        sn_inc_endpoint = '/api/now/table/incident?sysparm_query=active=true^incident_state=2'
        sn_inc_endpoint = sn_inc_endpoint + '^company.sys_id='+self.som_company_sys_id
        sn_inc_endpoint = sn_inc_endpoint + '^priority=3^ORpriority=4^ORpriority=2'
        #sn_inc_endpoint = sn_inc_endpoint + '^sys_created_on>=javascript:gs.beginningOfYesterday()'
        sn_inc_endpoint = sn_inc_endpoint + '^sys_created_onONLast2hours@javascript:gs.beginningOfLast2Hours()@javascript:gs.endOfLast2Hours()'
        # Host down
        sn_inc_endpoint = sn_inc_endpoint + '^descriptionLIKEnot%20responding%20to%20Ping'
        # Server System Uptime/Machine Reboot
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKESystem%20Up%20Time'
        # Windows CPU Utilization
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEcpu%20utilization%20on'
        # Linux CPU Utilization
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKECPU%20Utilization%20on'
        # Memory Utilization
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEMemory%20Usage%20on'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEMemory%20Used%20on'
        # Windows Disk usage
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEWinVolumeUsage^descriptionLIKEfilesystem^descriptionLIKEspace'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKE%20MONITORING%20%20Disk'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEDisk%20Space%20utilization'
        # Unix File system Utilization
        sn_inc_endpoint= sn_inc_endpoint + '^ORdescriptionLIKEFile%20System%20Utilization'
        # Windows CPU Performance Queue length
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKESystem%20Performance%20Processor%20Queue%20Length'
        # Linux Process
        # sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKELinux%20process'
        # Windows Hearbeat
        #sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEOpsRamp%20Agent%20service%20is%20offline'

        # Windows Service alert
        sn_inc_endpoint = sn_inc_endpoint + '^ORshort_descriptionLIKEWindows%20Service'
        sn_inc_endpoint = sn_inc_endpoint + '^ORshort_descriptionLIKEService%20Alert:'
        sn_inc_endpoint = sn_inc_endpoint + '^ORshort_descriptionLIKEPatrol%20Agent'

        # Network Unreachable to ping
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKENetwork%20Outage'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEDevice%20Reboot%20Detected'
        # SNMP Agent Not Responding
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKESNMP%20Agent%20Not%20Responding'
        #Wireless accesspoint alarm
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEAP%20Not%20Associated%20With%20Controller'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEAP%20Unreachable'
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEAP%20UNREACHABLE'
        # Network - Power Supply
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEpower%20supply'
        # Network Port Down
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEport%20down'
        # Wireless Access Point Antenna Offline
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEap%20antenna%20offline'
        # Port Utilization High
        sn_inc_endpoint = sn_inc_endpoint + '^ORdescriptionLIKEport%20utilization%20high'
        #BGP Peer check
        sn_inc_endpoint= sn_inc_endpoint + '^ORdescriptionLIKEBGP'
        #Temperature Alarm
        sn_inc_endpoint = sn_inc_endpoint + '^ORshort_descriptionLIKETemperature%20Alarm'
        # Network Host Down
        sn_inc_endpoint = sn_inc_endpoint + '^ORshort_descriptionLIKEnot%20responding%20to%20Ping'
        # define the which fiels needs to return from SOM API
        sn_inc_endpoint = sn_inc_endpoint + '&sysparm_fields=number,assignment_group,company,cmdb_ci,description,short_description,sys_id,priority,incident_state,opened_at'

        sn_inc_url = "https://{0}{1}".format(self.sn_url,
                                             sn_inc_endpoint)
        self._logger.info(sn_inc_url)
        sn_result = requests.request('GET',
                                     sn_inc_url,
                                     auth=(self.sn_username, self.sn_password),
                                     headers=self.servicenow_headers)

        sn_result.raise_for_status()
        sn_incidents = sn_result.json()['result']
        self.check_incidents(sn_incidents)
        self._logger.info('COMPLETED_INCIDENT_SENSOR_AT: {}'.format(datetime.now()))

    def check_incidents(self, sn_incidents):
        ''' Create a trigger to run cleanup on any open incidents that are not being processed
        '''
        inc_st2_key = 'servicenow.incidents_processing'
        processing_incs = self.st2_client.keys.get_by_name(inc_st2_key)

        processing_incs = [] if processing_incs is None else ast.literal_eval(processing_incs.value)
        self._logger.info('In servicenow_incident_sensor')
        
        for inc in sn_incidents:
            print("INC ",inc['number'])
            #print("Desc " , inc['description'])
            print("AG ", inc['assignment_group']) 
            # skip any incidents that are currently being processed
            if inc['number'] in processing_incs:
                self._logger.info('Already processing INC: ' + inc['number'])
                continue
            else:
                insert_output = self.check_description(inc)
                print("Insesrt ",insert_output)
                if insert_output == "true":
                    self._logger.info('Processing INC: ' + inc['number'])
                    processing_incs.append(inc['number'])
                    incs_str = str(processing_incs)
                    kvp = KeyValuePair(name=inc_st2_key, value=incs_str)
                    self.st2_client.keys.update(kvp)
                else:
                    continue

    def get_company_and_ag_and_ciname(self, inc):
        configuration_item_env = ''
        if inc['assignment_group'] and inc['assignment_group']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                    url=inc['assignment_group']['link'])
            assign_group = response['name']
        else:
            self._logger.info('Assignment Group not found for INC: ' + inc['number'])
            assign_group = ''

        if inc['company'] and inc['company']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                   url=inc['company']['link'])
            company = response['name']
        else:
            self._logger.info('Company not found for INC: ' + inc['number'])
            company = ''

        if inc['cmdb_ci'] and inc['cmdb_ci']['link']:
            response = self.base_action.sn_api_call(method='GET',
                                                   url=inc['cmdb_ci']['link'])
            configuration_item_name = response['name']
            configuration_item_env = response['u_environment'].lower()
        else:
            self._logger.info('Company not found for INC: ' + inc['number'])
            configuration_item_name = ''

        return assign_group, company,configuration_item_name,configuration_item_env

    def get_dns_name(self, inc, ci_address):
        try:
            if inc['cmdb_ci'] and inc['cmdb_ci']['link']:
                response = self.base_action.sn_api_call(method='GET', url=inc['cmdb_ci']['link'])
                dns_name = response['dns_domain']
                ci_ipaddress = response['ip_address']
                configuration_item_name = response['name']
            else:
                dns_name = ''
                ci_ipaddress = ''
                configuration_item_name = ''
        except:
            dns_name = ''
            ci_ipaddress = ''

        pattern_ci = re.findall("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}", ci_ipaddress)

        try:
            if configuration_item_name.count('.') > 0 and '.test' not in configuration_item_name.lower():
                ci_address = configuration_item_name
            elif pattern_ci:
                ci_address = pattern_ci[0]
            else:
                if(dns_name) and ci_address.count('.') <= 0:
                    dns_name = str(dns_name).strip()
                    ci_address = ci_address + '.' + dns_name
                else:
                    ci_address = ci_address
        except:
            ci_address = ci_address

        return ci_address


    def betweenString(self,value, a, b):
        # Find and validate before-part.
        pos_a = value.find(a)
        if pos_a == -1: return ""
        # Find and validate after part.
        pos_b = value.rfind(b)
        if pos_b == -1: return ""
        # Return middle part.
        adjusted_pos_a = pos_a + len(a)
        if adjusted_pos_a >= pos_b: return ""
        return value[adjusted_pos_a:pos_b]

    def afterString(self,value, a):
        # Find and validate first part.
        pos_a = value.rfind(a)
        if pos_a == -1: return ""
        # Returns chars after the found string.
        adjusted_pos_a = pos_a + len(a)
        if adjusted_pos_a >= len(value): return ""
        return value[adjusted_pos_a:]

    def beforeString(self,value, a):
        # Find first part and return slice before it.
        pos_a = value.find(a)
        if pos_a == -1: return ""
        return value[0:pos_a]

    def check_description(self, inc):
        desc = inc['description'].lower()
        short_desc = inc['short_description']
        insertto_datastore = "false"


        assign_group, company, configuration_item_name,configuration_item_env = self.get_company_and_ag_and_ciname(inc)
        print("AG2 ",assign_group)
        print(inc['number'])
 
        if (('is not responding to ping' in desc or 'system up time' in desc) and ('intel' in assign_group.lower() or 'wintel' in assign_group.lower() or 'linux' in assign_group.lower() or 'unix' in assign_group.lower() or 'nttds-is data compliance veeam' in assign_group.lower() or 'nttds-backup-goc-l1' in assign_group.lower()) and (str(inc['priority']) != '2')):
            insertto_datastore = "true"
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            ci_address = ''
            if assign_group == '':
                check_uptime = False
                os_type = ''
            else:
                check_uptime = True
                os_type = 'windows' if 'intel' in assign_group.lower() or 'InsSvc-Automated Patch Mgt Open Systems' in assign_group.lower() or 'NTTDS-Wintel Global L1' else 'linux'
            if 'system up time' in desc:
                ci_address = configuration_item_name
                #ci_address = desc.split(' ')[0]
                #ci_address = ci_address.strip()
                rec_short_desc = "system up time"
                rec_detailed_desc = "system up time"
            if 'is not responding to ping' in desc:
                #ci_address_end = desc.split(' is not responding to ping')[0]
                #ci_address = ci_address_end.split(' ')[-1]
                rec_short_desc = "is not responding to ping"
                rec_detailed_desc = "is not responding to ping"
                try:
                    ci_address = desc.split(" is not responding to ping")[0].split(' ')[-1]
                except:
                    ci_address = ''
            ci_address = ci_address.strip()
            ci_address = ci_address.lower()

            ci_address = self.get_dns_name(inc,ci_address)

            payload = {
                'assignment_group': assign_group,
                'check_uptime': check_uptime,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': os_type,
                'short_desc': inc['short_description'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            #self._sensor_service.dispatch(trigger='ntt_itsm.unreachable_ping', payload=payload)
        elif (('cpu utilization on' in desc) and ('automated patch mgt open systems' in assign_group.lower() or 'wintel' in assign_group.lower()) and (str(inc['priority']) != '2')):
            #assign_group, company = self.get_company_and_ag(inc)
            insertto_datastore = "true"
            ci_address_begin = desc.split('cpu utilization on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None
            ci_address = self.get_dns_name(inc,ci_address)
            payload = {
                'assignment_group': assign_group,
                #'ci_address': configuration_item_name,
                'ci_address': ci_address,
                'cpu_name': '_total',
                'cpu_type': 'ProcessorTotalProcessorTime',
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'incident_state': inc['incident_state'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold,
                'configuration_item_name' : configuration_item_name,
                #'rec_short_desc': ci_address,
                'rec_short_desc': 'cpu utilization',
                'rec_detailed_desc': 'cpu utilization'
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_cpu', payload=payload)
        #elif 'memory usage on' in desc or 'memory used on' in desc:
        elif (('memory usage on' in desc or 'memory used on' in desc) and ('linux' in assign_group.lower() or 'unix' in assign_group.lower()) and (str(inc['priority']) != '2')):
            insertto_datastore = "true"
            #assign_group, company = self.get_company_and_ag(inc)

            if 'memory usage on' in desc:
                ci_address_begin = desc.split('memory usage on ')[-1]
            else:
                ci_address_begin = desc.split('memory used on ')[-1]
            ci_address = ci_address_begin.split(' ')[0]
            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None
            ci_address = self.get_dns_name(inc,ci_address)
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'memory_threshold': threshold,
                'os_type': 'linux',
                'short_desc': inc['short_description']
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_memory', payload=payload)
        elif ((('winvolumeusage' in desc and 'c:' in desc) or ('volume capacity' in desc and 'c:' in desc)) and ('wintel' in assign_group.lower()) and (str(inc['priority']) != '2')):
            insertto_datastore = "true"
            #assign_group, company = self.get_company_and_ag(inc)
            print("Inside Wintel disk space")

            Find_Before = self.beforeString(desc,'c:')
            Find_Before = Find_Before.strip()
            ci_address =Find_Before
            ci_address = self.get_dns_name(inc,ci_address)

            if ', th is' in desc:
                threshold_begin = self.afterString(desc, 'th is')
                threshold_begin = threshold_begin.strip()
                threshold_begin_new = self.beforeString(threshold_begin,'.')
                threshold_begin_new = threshold_begin_new.strip()
                self._logger.info('Threshold Begin New' + threshold_begin_new)
                threshold_begin_new = int(threshold_begin_new)
                threshold = str(100- threshold_begin_new)
            else:
                if 'warn' in short_desc.lower():
                    threshold = "91"
                elif 'error' in short_desc.lower():
                    threshold = "95"
                elif 'critical' in short_desc.lower():
                    threshold = "98"
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'disk_name': "C",
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold,
                'rec_short_desc': 'logical disk free space',
                'rec_detailed_desc': ci_address,
                'configuration_item_name': configuration_item_name
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.high_disk', payload=payload)
        elif ('file system utilization' in desc and ('linux' in assign_group.lower() or 'unix' in assign_group.lower())):
            insertto_datastore = "true"
            #assign_group, company = self.get_company_and_ag(inc)

            if ' is ' in short_desc:
                #threshold = short_desc.split(' is ')[1].split('%')[0].strip()
                threshold = short_desc.split(' threshold ')[1].strip()
            else:
                threshold = '80'

            Find_After = self.afterString(desc, 'ip address')
            Find_After = Find_After.strip()
            Find_Before = self.beforeString(Find_After,' is ')
            ci_address = Find_Before.strip()

            Find_After = self.afterString(short_desc, 'Utilization of')
            Find_After = Find_After.strip()
            Find_Before = self.beforeString(Find_After,'on')
            mount_point = Find_Before.strip()

            if '/' not in mount_point:
                mount_point = '/' + mount_point
            else:
                mount_point = mount_point


            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'mount_point': mount_point,
                'file_threshold': threshold,
                'customer_name': company,
                'detailed_desc': desc,
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'short_desc': short_desc,
                'threshold_percent': threshold,
                'rec_detailed_desc': 'file system utilization',
                'rec_short_desc': 'file system utilization',
                'configuration_item_name': configuration_item_name
            }
            self._logger.info('Executing file system managment workflow')
            self._sensor_service.dispatch(trigger='ntt_itsm.unix_fs_management', payload=payload)
        elif (('memory usage on' in desc or 'memory used on' in desc) and ('automated patch mgt open systems' in assign_group.lower() or 'wintel' in assign_group.lower()) and (str(inc['priority']) != '2')):
            insertto_datastore = "true"
            #ci_address_begin = desc.split('memory usage on ')[-1]
            #ci_address = ci_address_begin.split(' ')[0]
            ci_address = ''
            rec_short_desc = ''
            rec_detailed_desc = ''

            if ', th is' in desc:
                threshold_begin = desc.split(', th is ')[-1]
                threshold = threshold_begin.split('%')[0]
            else:
                threshold = None

            if 'memory usage on' in desc:
                rec_short_desc = 'memory usage on'
                rec_detailed_desc = 'memory usage on'
                ci_address_begin = desc.split('memory usage on ')[-1]
                ci_address = ci_address_begin.split(' ')[0]
            elif 'memory used on' in desc:
                rec_short_desc = 'memory used on'
                rec_detailed_desc = 'memory used on'
                ci_address_begin = desc.split('memory used on ')[-1]
                ci_address = ci_address_begin.split(' ')[0]

            ci_address = self.get_dns_name(inc,ci_address)
            if 'physical memory' in desc:
                memory_type = 'Physical'
            elif 'virtual' in desc:
                memory_type = 'Virtual'
            elif ('physical' in desc or 'windows | memory usage |' in desc or  'memory utilization' in desc or 'memory usage on' in desc ):
                memory_type = 'Physical'
            elif ('high memory paging' in desc or 'paging is now' in desc):
               memory_type = 'PagesPerSec'
            elif ('paging file usage' in desc):
               memory_type = 'PagingFile'
            elif ('threshold of memory not met' in desc):
               memory_type = 'MemoryAvailableBytes'
            elif ('memory low:' in desc):
               memory_type = 'MemoryUsedBytesPct'
            else:
               memory_type = 'Physical'
            #cmdb_ci.name
            payload = {
                'assignment_group': assign_group,
                #'ci_address': ci_address,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold,
                'incident_state': inc['incident_state'],
                #'rec_short_desc': ci_address,
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                #'configuration_item_name': ci_address,
                'configuration_item_name': configuration_item_name,
                'memory_type':memory_type
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.win_memory_high', payload=payload)

        #elif ('Windows Service' in short_desc and 'is not running' in short_desc) and 'wintel' in assign_group.lower():
        elif ('windows service' in desc and 'is not running' in desc) and 'wintel' in assign_group.lower():
            print("Inside Windows Service")
            self._logger.info("Inside Windows Service trigger condition")
            insertto_datastore = "true"
            ci_address = ''
            rec_short_desc = ''
            rec_detailed_desc = ''

            if ('truesight' in short_desc.lower() or ('windows service' in short_desc.lower() and 'is not running host' in short_desc)):
               ci_address_begin = short_desc.strip().lower().split('truesight ')[-1]
               ci_address = ci_address_begin.split(' ')[0]

               Find_After = self.afterString(desc, 'DataPoint:')
               Find_After = Find_After.strip()
               Find_Before = self.beforeString(Find_After,'Operating System')
               Find_Before = Find_Before.strip()
               #rec_short_desc = 'Windows Service'
               #rec_detailed_desc = Find_Before
               service_name  = Find_Before
               rec_short_desc = short_desc
               rec_detailed_desc = desc

            #elif ('Windows Service' in short_desc and 'is not running' in short_desc ):
            elif ('windows service' in desc and 'is not running' in desc ):
               #print(desc)
               ci_address = short_desc.strip().split(' ')[0]
               print("CI Address ",ci_address)
               Find_After = self.afterString(desc, "datapoint:")
               Find_After = Find_After.strip()
               print("After ",Find_After)
               Find_Before = self.beforeString(Find_After,'operating system')
               print("Before ",Find_Before)
               Find_Before = Find_Before.strip()
               service_name  = Find_Before
               print("Service Name ",service_name)
               
               #rec_short_desc = 'Windows Service'
               #rec_detailed_desc = service_name
               rec_short_desc = short_desc
               rec_detailed_desc = desc

            elif ('external:' in short_desc.lower() and 'patrol agent' in short_desc.lower() and 'is disconnected' in short_desc ):
               ci_address_begin = short_desc.strip().lower().split(' ')[1]
               ci_address = ci_address_begin.split(' ')[0]
               service_name = 'PatrolAgent'
               rec_short_desc = short_desc
               rec_detailed_desc = desc

            elif ('patrol agent' in short_desc.lower() and 'is disconnected' in short_desc  ):
               ci_address = short_desc.strip().split(' ')[0]
               service_name = 'PatrolAgent'
               rec_short_desc = short_desc
               rec_detailed_desc = desc

            #if('.' not in ci_address):
                #try:
                    # If CI_adress is IP
                   # pattern_ci = re.findall("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}", ci_address)
                    #if pattern_ci:
                     #   ci_address = pattern_ci[0]
                    #else:
                        # if it is hostname
                     #   dns_name = self.get_dns_name(inc)
                      #  if(dns_name):
                      #      dns_name = str(dns_name).strip()
                           # ci_address = ci_address + '.' + dns_name
                #except:
                #    ci_address = ci_address

            ci_address = self.get_dns_name(inc,ci_address)

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'short_desc': inc['short_description'],
                'incident_state': inc['incident_state'],
                'service_name': service_name,
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.win_service_check', payload=payload)

        elif (('cpu utilization on' in desc) and ('linux' in assign_group.lower() or 'unix' in assign_group.lower() )):
            ci_address = ''
            insertto_datastore = "true"
            # ci_address_begin = desc.split('cpu utilization on ')[-1]
            # ci_address = ci_address_begin.split(' ')[0]

            Find_Before = self.beforeString(short_desc,'cpu utilization on')
            Find_Before =Find_Before.strip()
            ci_address = Find_Before
            self._logger.info("Find_Before " + ci_address)
            Find_After = self.afterString(ci_address, "is at ")
            Find_After = Find_After.strip()
            self._logger.info("Find_After " + Find_After)
            ci_address = Find_After
            rec_short_desc = 'CPU Utilization on'
            rec_detailed_desc = 'CPU Utilization on'
            ci_address = self.get_dns_name(inc,ci_address)
            if ', th is' in desc:
               # threshold_begin = desc.split(', th is ')[-1]
               # threshold = threshold_begin.split('%')[0]
               Find_After = self.afterString(desc, "th is")
               Find_After = Find_After.strip()
               threshold = Find_After

               Find_Before = self.beforeString(threshold,'%')
               Find_Before =Find_Before.strip()
               threshold = Find_Before
               threshold = self.beforeString(threshold,'.')
            else:
               threshold = 85

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'cpu_name': '_total',
                'cpu_type': 'ProcessorTotalProcessorTime',
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'linux',
                'short_desc': inc['short_description'],
                'threshold_percent': threshold,
                'incident_state': inc['incident_state'],
                'configuration_item_name' : configuration_item_name,
                'os_name' : "linux",
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc
            }
            self._logger.info('Processing INC: ' + inc['number'] + '' + str(payload))
            self._sensor_service.dispatch(trigger='ntt_itsm.linux_cpu_high', payload=payload)
        elif (('disk' in desc and 'is critical' in desc) and (('linux' in assign_group.lower()) or ('unix' in assign_group.lower())) and (str(inc['priority']) != '2')):
            ci_address = ''
            threshold = '85'
            Find_Before = self.beforeString(short_desc,'Disk')
            Find_Before =Find_Before.strip()
            ci_address = Find_Before
            Find_After = self.afterString(short_desc, "Threshold is")
            Find_After = Find_After.strip()
            threshold = Find_After
            disk_name_before = self.beforeString(short_desc,'Critical.Used')
            disk_name_before =disk_name_before.strip()
            disk_name = disk_name_before
            disk_name_after = self.afterString(disk_name_before, "Disk")
            disk_name_after = disk_name_after.strip()
            disk_name = disk_name_after
            rec_short_desc = 'Disk Capacity'
            rec_detailed_desc = disk_name
            insertto_datastore = "true"
            ci_address = self.get_dns_name(inc,ci_address)

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'short_desc': inc['short_description'],
                'incident_state': inc['incident_state'],
                'disk_name': disk_name,
                'os_type': 'linux',
                'disk_threshold': threshold,
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.disk_usage_check_linux', payload=payload)
        elif (('system performance processor queue length' in desc ) and ('intel' in assign_group.lower() or 'wintel' in assign_group.lower()) and (str(inc['priority']) != '2')):
            ci_address = ''
            rec_short_desc = ''
            rec_detailed_desc = ''
            desc_org = inc['description']
            insertto_datastore = "true"

            Find_Before = self.beforeString(desc_org,'System Performance')
            ci_address =Find_Before.strip()
            ci_address = self.get_dns_name(inc,ci_address)

            Find_After = self.afterString(desc_org, ">")
            Find_After = Find_After.strip()
            Find_Before = self.beforeString(Find_After,'Number')
            threshold_queue =Find_Before.strip()

            rec_short_desc = 'System Performance Processor Queue Length'
            rec_detailed_desc = 'System Performance Processor Queue Length'

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'threshold_queue': threshold_queue,
                'incident_state': inc['incident_state'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name,
                'cpu_type':'ProcessorQueueLength'
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.win_cpu_queue_length', payload=payload)

        elif (('is not running on host' in desc) and ('linux' in desc) and (str(inc['priority']) != '2')):
            #service
            service_begin = desc.split('is not running on host')[0]
            service = service_begin.split('Linux process')[-1]
            service = service.strip()
            #CI Name
            ci_name_begin = desc.split('is not running on host')[-1]
            ci_name = ci_name_begin.strip()
            insertto_datastore = "true"
            ci_address = self.get_dns_name(inc,ci_address)

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'os_type': 'linux',
                'short_desc': inc['short_description'],
                'service': service,
                'incident_state': inc['incident_state'],
                'configuration_item_name': ci_name
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.unix_process_alert', payload=payload)

        elif (('opsramp agent service is offline' in desc ) and ('intel' in assign_group.lower() or 'wintel' in assign_group.lower()) and (str(inc['priority']) != '2')):

            ci_address = ''
            rec_short_desc = ''
            rec_detailed_desc = ''
            desc_org = inc['description']
            Find_Before = self.beforeString(desc_org,'OpsRamp Agent service is offline')
            ci_address =Find_Before.strip()
            insertto_datastore = "true"
            ci_address = self.get_dns_name(inc,ci_address)

            rec_short_desc = 'OpsRamp agent is offline '
            rec_detailed_desc = 'OpsRamp Agent service is offline'
            # self._logger.info('Already processing INC: ' + inc['number'] +'incident_open_at' + inc['opened_at'] )
            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'incident_open_at': inc['opened_at'],
                'os_type': 'windows',
                'short_desc': inc['short_description'],
                'incident_state': inc['incident_state'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name,
                'configuration_item_env': configuration_item_env
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.win_monitoring_heartbeat_failure', payload=payload)
        elif ((('network outage' in desc ) or ('device reboot detected' in desc ) or ('device cold reboot' in desc)) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower())):
            insertto_datastore = "true"
            desc_org = inc['description']
            if (( 'NMSENVPOLL' in desc_org ) and ( 'Network Outage' in desc_org)):
                Find_Before = self.beforeString(desc_org,': Network Outage')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()
            elif (( 'NMSENVPOLL' in desc_org ) and ( 'Device Reboot Detected' in desc_org)):
                Find_Before = self.beforeString(desc_org,': Device Reboot Detected')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()
            elif (( 'NMSENVPOLL' in desc_org ) and ( 'Device Cold Reboot' in desc_org)):
                Find_Before = self.beforeString(desc_org,': Device Cold Reboot')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()
            else:
                Find_Before = self.beforeString(desc_org,':Network Outage')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                Find_Between = Find_Between.strip()
                Find_After = self.afterString(Find_Between, ":")
                ci_address = Find_After.strip()

            if 'Network Outage' in desc_org:
                Find_After = self.afterString(short_desc, 'Entuity : ')
                Find_After_short = Find_After.strip()
                self._logger.info("Find_After " + Find_After_short)
                Find_Before = self.beforeString(desc_org,': Node Unreachable')
                Find_Before = Find_Before.strip()
                Find_After = self.afterString(Find_Before, "NMSENVPOLLPTC07.nttdataservices.com : ")
                Find_After_des = Find_After.strip()
                self._logger.info("Find_After " + Find_After_des)
                rec_short_desc = Find_After_short
                rec_detailed_desc = Find_After_des
            elif 'Device Reboot Detected' in desc_org:
                rec_short_desc = 'device reboot detected'
                rec_detailed_desc = 'device reboot detected'
            elif 'Device Cold Reboot' in desc_org:
                rec_short_desc = 'Device Cold Reboot'
                rec_detailed_desc = 'Device Cold Reboot'

           # if configuration_item_name == "Event_CI_Not Found":
           #    Find_After = self.afterString(short_desc, 'Entuity : ')
           #    Find_After_short = Find_After.strip()
           #    self._logger.info("Find_After " + Find_After_short)
           #    Find_Before = self.beforeString(desc_org,': Node Unreachable')
           #     Find_Before = Find_Before.strip()
           #    #Find_Between = self.betweenString(Find_Before,":",":")
           #    #Find_Between = Find_Between.strip()
           #    Find_After = self.afterString(Find_Before, "NMSENVPOLLPTC07.nttdataservices.com : ")
           #    Find_After_des = Find_After.strip()
           #     self._logger.info("Find_After " + Find_After_des)
           #     rec_short_desc = Find_After_short
           #     rec_detailed_desc = Find_After_des

            payload = {
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'ci_address': ci_address,
                'assignment_group': assign_group,
                'customer_name': company,
                'short_desc': inc['short_description'],
                'detailed_desc': inc['description'],
                'incident_state': inc['incident_state'],
                'incident_open_at': inc['opened_at'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            if '-rt' in configuration_item_name.lower() and str(inc['priority']) == '3':
                self._sensor_service.dispatch(trigger='ntt_itsm.network_outage_elevated', payload=payload)
            else:
                self._sensor_service.dispatch(trigger='ntt_itsm.nw_unreachable_to_ping', payload=payload)
        elif (('snmp agent not responding' in desc ) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower())):
            insertto_datastore = "true"
            desc_org = inc['description']
            ci_address = ''
            if (( 'NMSENVPOLL' in desc_org )):
                Find_After = self.afterString(desc_org,'nttdataservices.com :')
                Find_Before = self.beforeString(Find_After,':')
                ci_address = Find_Before.strip()


            rec_short_desc = 'snmp agent not responding'
            rec_detailed_desc = 'snmp agent not responding'

            payload = {
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'ci_address': ci_address,
                'assignment_group': assign_group,
                'customer_name': company,
                'short_desc': inc['short_description'],
                'detailed_desc': inc['description'],
                'incident_state': inc['incident_state'],
                'incident_open_at': inc['opened_at'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.nw_snmp_not_responding', payload=payload)
        elif('ap antenna offline' in desc) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower()):
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            insertto_datastore = "true"
            short_desc_org = inc['short_description']

            Find_After = self.afterString(short_desc_org, "Entuity :")
            Find_After = Find_After.strip()
            Find_Between_ap = self.betweenString(Find_After,":",":")
            accesspoint_name = Find_Between_ap.strip()

            Find_Before = self.beforeString(short_desc_org,': AP Antenna Offline')
            Find_Before = Find_Before.strip()
            Find_Between_ci = self.betweenString(Find_Before,":",":")
            ci_address = Find_Between_ci.strip()

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'incident_state': inc['incident_state'],
                'short_desc': inc['short_description'],
                'configuration_item_name': configuration_item_name,
                'rec_short_desc': 'ap antenna offline',
                'rec_detailed_desc': ci_address,
                'accesspoint_name': accesspoint_name
            }
            print("Dispatching the trigger")
            self._sensor_service.dispatch(trigger='ntt_itsm.wireless_accesspoint_antenna_offline_alarm', payload=payload)
        elif( ('power supply' in desc and 'fault' in desc) or ('power supply unknown status' in desc) or ('power supply status on' in desc) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower())):
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            insertto_datastore = "true"
            desc_org = inc['description']
            short_desc_org = inc['short_description']
            ci_address = ''
            if (('NMSENVPOLL' in desc_org) and ('Power Supply' in desc_org) and ('Fault' in desc_org)):
                Find_Before_fault = self.beforeString(desc_org,'Fault')
                Find_Before = self.beforeString(Find_Before_fault,': Switch')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()
            elif (('NMSENVPOLL' in desc_org) and ('Power Supply Unknown Status' in desc_org) and (': unknown :' in desc_org)):
                Find_Before = self.beforeString(desc_org,': unknown')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()
            elif (('NMSENVPOLL' in desc_org) and ('Power Supply Unknown Status' in desc_org) and (': RPS Container' in desc_org)):
                Find_Before = self.beforeString(desc_org,': RPS Container')
                Find_Before = Find_Before.strip()
                Find_Between = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between.strip()

            payload = {
                'assignment_group': assign_group,
                'ci_address': ci_address,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'incident_state': inc['incident_state'],
                'short_desc': inc['short_description'],
                'configuration_item_name': configuration_item_name,
                'rec_short_desc': 'power supply',
                'rec_detailed_desc': ci_address
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.network_power_supply_down', payload=payload)
        elif((('ap not associated with controller' in desc ) or ('ap unreachable' in desc) or ('AP Unreachable' in desc)) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower())):
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            insertto_datastore = "true"
            short_desc_org = inc['short_description'].lower()
            short_desc_org_ap = inc['short_description']
            Find_After = self.afterString(short_desc_org_ap, "Entuity :")
            Find_After = Find_After.strip()
            Find_Between_ap = self.betweenString(Find_After,":",":")
            accesspoint_name = Find_Between_ap.strip()
            try:
             if 'ap not associated with controller' in short_desc_org:
                Find_Before = self.beforeString(short_desc_org,': ap not associated with controller')
                Find_Before = Find_Before.strip()
                Find_Between_ci = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between_ci.strip()
             elif 'ap unreachable' in short_desc_org:
                Find_Before = self.beforeString(short_desc_org,': ap unreachable (icmp)')
                Find_Before = Find_Before.strip()
                Find_Between_ci = self.betweenString(Find_Before,":",":")
                ci_address = Find_Between_ci.strip()
             if 'ap not associated with controller' in short_desc_org:
                rec_short_desc = 'ap not associated with controller'
             elif 'ap unreachable' in short_desc_org:
                rec_short_desc = 'ap unreachable'
             Find_Before = self.beforeString(desc,':')
             Find_Before = Find_Before.strip()
             nms_poll_data = self.beforeString(Find_Before,'.')
             if '|' in nms_poll_data:
                 nms_poll_data = nms_poll_data.split('|')[1]
             nms_poll_data = nms_poll_data.strip()

             payload = {
                    'wlc_ip': ci_address,
                    'company': company,
                    'detailed_desc': inc['description'],
                    'inc_number': inc['number'],
                    'inc_sys_id': inc['sys_id'],
                    'short_desc': inc['short_description'],
                    'wap_name': accesspoint_name,
                    'entuity_name': nms_poll_data.lower(),
                    'assignment_group': assign_group,
                    'configuration_item_name': configuration_item_name
             }
             self._sensor_service.dispatch(trigger='ntt_itsm.nw_wap_alert_check', payload=payload)
             #payload = {
             #   'assignment_group': assign_group,
             #   'ci_address': ci_address,
             #   'customer_name': company,
             #   'detailed_desc': inc['description'],
             #   'inc_number': inc['number'],
             #   'inc_sys_id': inc['sys_id'],
             #   'incident_state': inc['incident_state'],
             #   'short_desc': inc['short_description'],
             #   'configuration_item_name': configuration_item_name,
             #   'rec_short_desc': rec_short_desc,
             #   'rec_detailed_desc': ci_address,
             #   'accesspoint_name': accesspoint_name
             #}
             #self._sensor_service.dispatch(trigger='ntt_itsm.wireless_accesspoint_alarm', payload=payload)
            except:
               print('check description error')


        elif( 'port down' in desc ) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower()):
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            insertto_datastore = "true"
            #assign_group, company = self.get_company_and_ag(inc)
            ifindex=''
            mib=''
            workflow_type=''
            rec_short_desc=''
            rec_detailed_desc=''
            desc_org = inc['description']

            if 'ifindex=' in desc:
                workflow_type='PortLink'
                Find_After = self.afterString(desc,'ifindex=')
                ifindex = Find_After.strip()
            else:
                workflow_type='PortOper'
                Find_After = self.afterString(short_desc,'[')
                Find_After = Find_After.strip()
                Find_Before = self.beforeString(Find_After,']')
                mib=Find_Before.strip()


            Find_After = self.afterString(short_desc,'Entuity :')
            Find_After = Find_After.strip()
            Find_Before = self.beforeString(Find_After,':')
            device_ip=Find_Before.strip()

            Is_Entuity = 'false'

            Find_After = self.afterString(short_desc, 'Entuity : ')
            Find_After_short = Find_After.strip()
            self._logger.info("Find_After " + Find_After_short)
            rec_short_desc = Find_After_short
            if 'Admin up' in desc_org:
                Find_Before = self.beforeString(desc_org,': Admin up')
                Find_Before = Find_Before.strip()
                Find_After = self.afterString(Find_Before, "nttdataservices.com : ")
                Find_After_des = Find_After.strip()
                self._logger.info("Find_After " + Find_After_des)
                rec_detailed_desc = Find_After_des
            if 'ifIndex' in desc_org:
                Find_Before = self.beforeString(desc_org,': ifIndex')
                Find_Before = Find_Before.strip()
                Find_After = self.afterString(Find_Before, "nttdataservices.com : ")
                Find_After_des = Find_After.strip()
                self._logger.info("Find_After " + Find_After_des)
                rec_detailed_desc = Find_After_des

            payload = {
                'assignment_group': assign_group,
                'device_ip': device_ip,
                'customer_name': company,
                'detailed_desc': inc['description'],
                'ifindex': ifindex,
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'mib': mib,
                'short_desc': short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'rec_short_desc': rec_short_desc,
                'Is_Entuity' : Is_Entuity,
                'device_name': configuration_item_name,
                'workflow_type': workflow_type
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.nw_port_down', payload=payload)
        elif ( 'port utilization high' in desc ) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower()):
            #assign_group, company = self.get_company_and_ag_and_ciname(inc)
            insertto_datastore = 'true'
            desc_org = inc['description']
            rec_short_desc= inc['short_description']
          #  rec_detailed_desc='port utilization'
            ci_address = desc.split(': ')[1]
            ci_address = ci_address.strip()
            interface_descr = self.betweenString(desc_org, '[', ']').strip()
            utilization_threshold = int(float(desc_org.split('threshold=')[1].split('%')[0]))

            payload = {
                'assignment_group': assign_group,
                'snmp_ip': ci_address,
                'customer_name': company,
                'configuration_item_name': configuration_item_name,
                'interface_descr': interface_descr,
                'utilization_threshold': utilization_threshold,
                'detailed_desc': desc_org,
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'short_desc': inc['short_description'],
                'rec_detailed_desc': ci_address,
                'rec_short_desc': rec_short_desc
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.port_utilization', payload=payload)

        elif ('temperature alarm' in desc) and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower()):

            target_ip = short_desc.split(':')[1]
            nms_server = desc.split(':')[0].split('.')[0]
            desc_org = inc['description']
            short_desc = inc['short_description']
            insertto_datastore = "true"

            Find_After = self.afterString(short_desc, 'Entuity : ')
            Find_After_short = Find_After.strip()
            self._logger.info("Find_After " + Find_After_short)
            Find_Before = self.beforeString(desc_org,': Chassis temperature alarm on')
            Find_Before = Find_Before.strip()
            #Find_Between = self.betweenString(Find_Before,":",":")
            #Find_Between = Find_Between.strip()
            Find_After = self.afterString(Find_Before, "NMSENVPOLLPTC07.nttdataservices.com : ")
            Find_After_des = Find_After.strip()
            self._logger.info("Find_After " + Find_After_des)
            rec_short_desc = Find_After_short
            rec_detailed_desc = Find_After_des
            #rec_detailed_desc = 'Temperature Alarm'
            #rec_short_desc = 'Temperature Alarm'

            payload = {
                    'assignment_group': assign_group,
                    'customer_name': company,
                    'detailed_desc': inc['description'],
                    'inc_number': inc['number'],
                    'inc_sys_id': inc['sys_id'],
                    'incident_state': inc['incident_state'],
                    'short_desc': inc['short_description'],
                    'rec_detailed_desc': rec_detailed_desc,
                    'rec_short_desc': rec_short_desc,
                    'target_ip': target_ip,
                    'configuration_item_name': configuration_item_name,
                    'nms_server': nms_server
            }
            self._sensor_service.dispatch(trigger='ntt_itsm.nw_temperature_alarm', payload=payload)

        elif ('bgp peer' in desc) and (str(inc['priority']) != '2') and ('netops' in assign_group.lower() or 'firewall' in assign_group.lower() or 'load balancer' in assign_group.lower()):
            insertto_datastore = "true"
            self._logger.info("Inside bgp peer trigger condition")
            desc_org = inc['description']
            os_type = 'linux'
            rec_short_desc='BGP Peer'
            rec_detailed_desc='BGP Peer'

            ci_address = desc.split(': ')[1]
            ci_address = ci_address.strip()
            peer_ip_end = desc.split('peer to ')[1]
            peer_ip = peer_ip_end.split(')')[0]
            peer_ip = peer_ip.strip()


            Find_Before = self.beforeString(desc,':')
            Find_Before = Find_Before.strip()
            nms_poll_data = self.beforeString(Find_Before,'.')
            if '|' in nms_poll_data:
                nms_poll_data = nms_poll_data.split('|')[1]
            nms_poll_data = nms_poll_data.strip()

            payload = {
                'inc_number': inc['number'],
                'inc_sys_id': inc['sys_id'],
                'ci_address': ci_address,
                'assignment_group': assign_group,
                'customer_name': company,
                'short_desc': inc['short_description'],
                'detailed_desc': desc_org,
                'incident_state': inc['incident_state'],
                'incident_open_at': inc['opened_at'],
                'rec_short_desc': rec_short_desc,
                'rec_detailed_desc': rec_detailed_desc,
                'configuration_item_name': configuration_item_name
            }
            if '-rt' in configuration_item_name.lower() and str(inc['priority']) == '3':
                self._sensor_service.dispatch(trigger='ntt_itsm.network_outage_elevated', payload=payload)
            else:
                payload = {
                    'inc_number': inc['number'],
                    'inc_sys_id': inc['sys_id'],
                    'device_ip': ci_address,
                    'assignment_group': assign_group,
                    'customer_name': company,
                    'short_desc': inc['short_description'],
                    'detailed_desc': desc_org,
                    'peer_ip': peer_ip,
                    #'incident_state': inc['incident_state'],
                    #'incident_open_at': inc['opened_at'],
                    'rec_short_desc': rec_short_desc,
                    'rec_detailed_desc': rec_detailed_desc,
                    'device_name': configuration_item_name
                }
                #self._logger.info('BGP Peer check workflow is not deployed for stackstorm')
                self._sensor_service.dispatch(trigger='ntt_itsm.bgp_peer_check', payload=payload)

        elif (('is not responding to ping' in desc) and ('nttds-is netops' in assign_group.lower() )):

            device_name = short_desc.split(" ")[1]
            desc_org = inc['description']
            short_desc = inc['short_description']
            insertto_datastore = "true"


            rec_short_desc = short_desc
            rec_detailed_desc = device_name
            #rec_detailed_desc = 'Temperature Alarm'
            #rec_short_desc = 'Temperature Alarm'

            payload = {
                    'assignment_group': assign_group,
                    'customer_name': company,
                    'detailed_desc': inc['description'],
                    'inc_number': inc['number'],
                    'inc_sys_id': inc['sys_id'],
                    'short_desc': inc['short_description'],
                    'device_name': device_name,
                    'configuration_item_name': configuration_item_name,
                    'rec_short_desc': rec_short_desc,
                    'rec_detailed_desc': rec_detailed_desc
            }
            #print(payload)
            self._sensor_service.dispatch(trigger='ntt_itsm.nw_host_down', payload=payload)

        return insertto_datastore

    def cleanup(self):
        pass

    def add_trigger(self, trigger):
        pass

    def update_trigger(self, trigger):
        pass

    def remove_trigger(self, trigger):
        pass


