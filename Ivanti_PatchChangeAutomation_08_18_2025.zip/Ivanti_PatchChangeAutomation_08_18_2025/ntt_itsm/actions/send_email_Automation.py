#!/usr/bin/env python
import socket
from st2client.client import Client
from st2common.runners.base_action import Action
import smtplib
import email.utils
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import os
from email.header import Header
from email.mime.application import MIMEApplication
import requests
import json

class SendEmailAutomation(Action):
    def run(self, email_from,receiver_emails,subject,message_body,smtp_server,email_cc,mime,attachments,message_from):
        #email_from = kwargs['email_from']
        email_to = receiver_emails
        #subject = kwargs['subject']
        message = message_body
        #smtp_server = kwargs['smtp_server']
        #email_cc = kwargs['email_cc']
        #mime = kwargs['mime']
        #print(mime)
        #attachments = kwargs['attachments']
        port = 25
        #print("Input:", email_from,email_to,subject,message,attachments)

        if mime not in ['plain', 'html']:
            raise ValueError('Invalid mime provided: ' + mime)
        msg_body_data = message
        send_mail_sts = (False, 'NONE')
        message = MIMEMultipart()
        if len(str(email_cc)) >= 0 and email_cc != None and str(email_cc) != '':
            email_to_list = email_cc.split(",") + email_to.split(',')
        else:
            email_to_list = email_to.split(',')
        message['To'] = email.utils.formataddr(('Recipient', email_to))
        message['From'] = email.utils.formataddr((message_from, email_from))
        message['Subject'] = subject
        #data = 'automation test'
        message.attach(MIMEText(msg_body_data, mime, 'utf-8'))
        if len(str(attachments)) >= 0 and attachments != None and str(attachments) != '':
            attachments = attachments.split(',')
            for filepath in attachments:
                filename = os.path.basename(filepath)
                with open(filepath, 'rb') as f:
                    part = MIMEApplication(f.read(), Name=filename)
                part['Content-Disposition'] = 'attachment; filename="{}"'.format(filename)
                message.attach(part)
        if len(str(email_cc)) >= 0 and email_cc != None and str(email_cc) != '':
            #message['Cc'] = ", ".join(email_cc)
            message['Cc'] = email_cc
        
        try:
            server = None # Initialize server
            server = smtplib.SMTP(smtp_server, port)
            server.set_debuglevel(False)
            #server.sendmail(email_from, email_to_list, message.as_string())
            #server.sendmail("noreply@nttdso.net","Sreedevi.An@nttdata.com" , message.as_string())
         
            url = "https://api.sendgrid.com/v3/mail/send"
            #payload = json.dumps({"personalizations": [{"to": [{"email": "Sreedevi.An@nttdata.com"}]}],"from": {"email": "noreply@nttdso.net"},"subject": subject,"content": [{"type": "text/plain","value": message_body}]})
            payload = json.dumps({"personalizations": [{"to": [{"email": receiver_emails}]}],"from": {"email": email_from},"subject": subject,"content": [{"type": "text/plain","value": message_body}]})
            headers = {'Content-Type': 'application/json','Authorization': 'Bearer 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'}
            print(payload)
            response = requests.request("POST", url, headers=headers, data=payload)
            send_mail_sts = (True, 'MAIL_SENT_SUCCESSFULLY')
            print(response.text)
        except Exception as e:
            send_mail_sts = (False, ('ERROR_SENDING_MAIL', e))
            print(send_mail_sts)
        finally:
            server.quit()

        return send_mail_sts

