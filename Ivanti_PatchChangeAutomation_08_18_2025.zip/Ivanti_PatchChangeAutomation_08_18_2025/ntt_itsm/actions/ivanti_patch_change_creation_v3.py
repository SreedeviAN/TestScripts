#!/usr/bin/env python

#Stackstorm action Module
from lib.base_action import BaseAction

#API Request Module
import requests
from requests_ntlm import HttpNtlmAuth
from requests.auth import HTTPBasicAuth

#DateTime Module
import pytz
from datetime import datetime, timedelta

#Email Modules
import smtplib
import email.utils
from email.mime.text import MIMEText

#Json Module
import json

#sleep module
from time import sleep

#subprocess module - importing only check_output to get the output of the shell script executed
from subprocess import check_output
import subprocess
import paramiko

#winrm module
import winrm
#xml module
import xml.etree.ElementTree as ET
import re
import os

class IvantiPatchChangeCreationv3(BaseAction):
    def __init__(self, config):
        """Creates a new Action given a StackStorm config object (kwargs works too)
        :param config: StackStorm configuration object for the pack
        :returns: a new Action
        """
        super(IvantiPatchChangeCreationv3, self).__init__(config)

    def run(self, ivanti_server,ivanti_username, ivanti_password, winrm_username, winrm_password, companyname, assignment_group, change_management_group, req_by_email, day_difference,short_desc, detailed_desc, change_id, change_sys_id, configuration_item_env, planned_start_date, planned_end_date,os_type):
        
        scan_folder = "C:\\Windows\\System32\\Tasks\\Ivanti\\Security Controls\\Scans"
        start_boundary = ''
        end_boundary = ''
        machine_group_name = ''
        cdata_content = ''
        deploy_id = ''
        auto_deploy = 'NO'
        startdate = ''
        enddate = ''    
        scan_file_exists = 0

        servervalidate = []
        serverconnectivityfailedformat=''
        serverconnectivityfailed = []
        transferdetails = []
        servernotincmdb = []
        servertransferdetails = {}
        serverstoignore = []
        changescreated = []
        nopatch_servers = []         
       
        change_plan = 'Test Change Plan'
        test_plan = 'Test Plan'
        backout_plan = 'Test Backout Plan'
        
        chg_scanfile_name = detailed_desc.split("Patch Scan File Name: ")[1]
        #print(chg_scanfile_name)       
        chg_scanfile_name = chg_scanfile_name.split("Machine Group Name")[0]
        chg_scanfile_name = chg_scanfile_name.strip()
        print("chg_scnafile_name - ",chg_scanfile_name)
        chg_machine_grp_name = detailed_desc.split("Machine Group Name:")[1]
        chg_machine_grp_name = chg_machine_grp_name.split("----")[0]
        chg_machine_grp_name = chg_machine_grp_name.strip()
        print("chg_machine_grp_name - ", chg_machine_grp_name )
        
        url = self.config['servicenow']['url']
        self.sn_username = self.config['servicenow']['username']
        self.sn_password = self.config['servicenow']['password']
        headers = { "Content-Type":"application/json" }
        session = winrm.Session(f'https://' + ivanti_server + ':5986/wsman', auth=(ivanti_username,ivanti_password), transport='ntlm',server_cert_validation='ignore')        
        list_scanfiles_cmd = 'Get-ChildItem "C:\\Windows\\System32\\Tasks\Ivanti\\Security Controls\\Scans" -File | % { $_.FullName }'
        list_result =  session.run_ps(list_scanfiles_cmd)
        files = list_result.std_out.decode().splitlines()
        files = [f.strip() for f in files if f.strip()]
        
        if files:
            for file in files:
                #Read file content
                file_read_cmd = 'Get-Content -Path "'+ file +'" -Raw'
                file_read_result =  session.run_ps(file_read_cmd)
                file_name = str(file.split("Scans\\")[1])
                print(file_name)
                xml_content = file_read_result.std_out.decode()
                
                if file_name == chg_scanfile_name: 
                    scan_file_exists = 1
                    print("Scan File exists")
                    try:
                        root = ET.fromstring(xml_content)
                        ns = { 't': 'http://schemas.microsoft.com/windows/2004/02/mit/task'}
                        start_boundary_elem = root.find(".//t:StartBoundary",ns)
                        start_boundary = start_boundary_elem.text
                        end_boundary_elem = root.find(".//t:EndBoundary",ns)
                        end_boundary = end_boundary_elem.text
                        machine_group_name_elem = root.find(".//t:Description",ns)
                        machine_group_name = machine_group_name_elem.text
                        action_xml_elem = root.findall(".//t:Data",ns)[1]
                        inner_root = ET.fromstring(action_xml_elem.text)
                        method_node = inner_root.find(".//method")
                        if method_node is not None:
                            arg01 = method_node.attrib.get("arg01","")
                            #print("arg01= ",arg01)
                            if "-deployid" in arg01:
                                auto_deploy = "YES"
                            else:
                                auto_deploy = "NO"
                                #print("auto deploy value: ",auto_deploy)
                            if start_boundary is not None:
                                print(start_boundary)
                            else:
                                print("No StartBoundary value")
                            if end_boundary is not None:
                                print(end_boundary)
                            else:
                                print("No EndBoundary value")
                            if machine_group_name is not None:
                                print(machine_group_name)
                            else:
                                print("No Machine Group value")
                    except ET.ParseError as e:
                        print("XML Parse Error: {e}")
                    print("auto deploy value: ",auto_deploy)
                    
                    if auto_deploy == "YES":
                        try:
                            #Get the Machine Group Id
                            apiheader = {'Accept': 'application/json','Content-type': 'application/json'}
                            ivanti_group_url = "https://" + ivanti_server + ":3121/st/console/api/v1.0/machinegroups?name=" + machine_group_name        
                            ivanti_groups = requests.get(ivanti_group_url, auth=HttpNtlmAuth(ivanti_username,ivanti_password),headers=apiheader,verify=False)
                            ivanti_groups_json = ivanti_groups.json()
                            ivanti_group_id = ivanti_groups_json['value'][0]['id']
                
                            start_boundary = start_boundary.strip()
                            if '.' in start_boundary:
                                start_boundary = start_boundary.split('.')[0]
                            timesplit = start_boundary.split("-")
                            time1 = timesplit[2].split("T")[1].split(":")
                            servernextpatchtime = datetime(int(timesplit[0]),int(timesplit[1]),int(timesplit[2].split("T")[0]),int(time1[0]), int(time1[1]), int(time1[2].split("+")[0]))
                            timediff = servernextpatchtime - (datetime.now())
                            print("timediff: ", timediff)
                            end_boundary = end_boundary.strip()
                            if '.' in end_boundary:
                                end_boundary = end_boundary.split('.')[0]
                            timesplit1 = end_boundary.split("-")
                            time2 = timesplit1[2].split("T")[1].split(":")
                            serverendpatchtime = datetime(int(timesplit1[0]),int(timesplit1[1]),int(timesplit1[2].split("T")[0]),int(time2[0]), int(time2[1]), int(time2[2].split("+")[0]))
                            startdate = str(servernextpatchtime)
                            enddate = str(serverendpatchtime)
                            print(startdate)
                            print(enddate)
                            suppression_start = str((servernextpatchtime + timedelta(minutes=1)))
                            suppression_end = str((serverendpatchtime - timedelta(minutes=1)))
                            if machine_group_name == chg_machine_grp_name:
                                if startdate == planned_start_date:
                                    #Get the Machines in the Machine Group and create Patch Change for each Server
                                    server_data_url = "https://" + ivanti_server + ":3121/st/console/api/v1.0/machinegroups/"+str(ivanti_group_id)+"/discoveryfilters?category=MachineName"
                                    serverdata = requests.get(server_data_url, auth=HttpNtlmAuth(ivanti_username,ivanti_password), headers=apiheader, verify
=False)
                                    serverdatajson = serverdata.json()
                                    servers = ''
                                    for server in serverdatajson['value']:
                                        if server['category'] == 'MachineName':
                                            servers = servers + '\n' +  server['name']
                                    print("Servers ", servers)
                                    if timediff.days == day_difference:
                                        for server in serverdatajson['value']:
                                            servername = ivanti_server
                                            ivanti_server = server['name']
                                            servervalidate.append(ivanti_server)
                                            print("Next Patch window is {} which is {} days away from today".format(servernextpatchtime.astimezone(pytz.timezone('GMT')),day_difference))
                                            self.sn_username = self.config['servicenow']['username']
                                            self.sn_password = self.config['servicenow']['password']
                                            sn_url = self.config['servicenow']['url']
                                            cmdb_ci_check_api =  "/api/now/table/cmdb_ci?sysparm_query=name=" + ivanti_server + "^install_status=4"
                                            sn_url = "https://{0}{1}".format(url, cmdb_ci_check_api)
                                            self.servicenow_headers = {'Content-type': 'application/json','Accept': 'application/json'}
                                            serverbooleanresult = 0
                                                
                                            cmdb_ci_result = requests.request('GET', sn_url, auth=(self.sn_username, self.sn_password), headers=self.servicenow_headers, verify=False)
                                            cmdb_ci_result = cmdb_ci_result.json()
                                            resultlength = len(cmdb_ci_result['result'])
                                            install_status = cmdb_ci_result['result'][0]['install_status']
                                            if resultlength > 0:
                                                if install_status == '4':
                                                    print("Server {} is available in CMDB and it is Operational".format(servername))
                                                    serverbooleanresult = 1
                                                else:
                                                    print("Server {} is either not available or not Operational in CMDB".format(servername))
                                                    serverbooleanresult = 0

                                            #Performing Connectivity check
                                            if "Wintel" in assignment_group:
                                                os_type = "Windows"
                                            servername = ivanti_server
                                            domain_result = {"username": winrm_username, "password": winrm_password, "ci_address_fqdn": servername}
                                            shell_server_fqdn = domain_result["ci_address_fqdn"]
                                            shell_username = domain_result["username"]
                                            shell_password = domain_result["password"]
                                            try:
                                                connectivity_result = subprocess.check_output("bolt command run 'hostname' --targets winrm://" + shell_server_fqdn + " --user '" + shell_username + "' --password '" + shell_password + "' --no-ssl", shell=True)
                                            except subprocess.CalledProcessError as e:
                                                #print("command '{}' return with error (code {}): {}".format(e.cmd, e.returncode, e.output))
                                                connectivity_result = b'Failed'
                                                print(connectivity_result)
                                            connectivity_result_decoded = connectivity_result.decode('utf-8')
                                            print("Result decoded ", connectivity_result_decoded)
                                            if "success" in connectivity_result_decoded.lower():
                                                serverconnectivityresult = 1
                                                print("server {} is successfully connected with username {} and the result is: {}".format(shell_server_fqdn, domain_result["username"], connectivity_result_decoded))
                                            else:
                                                serverconnectivityresult = 0
                                                serverconnectivityfailedformat = shell_server_fqdn + " - credentials used:  " + domain_result["username"] + " - output is: "+ connectivity_result_decoded
                                                serverconnectivityfailed.append(serverconnectivityfailedformat)
                                                print("Connectivity Failed ", shell_server_fqdn)
                                            if serverbooleanresult == 1 and serverconnectivityresult == 1:
                                                shortdescription = "[TR - Automation] ||  " + os_type + " Ivanti Patch Change || " + "Primary Change Number - " + change_id
                                                startdate = str(servernextpatchtime)
                                                enddate = str(serverendpatchtime)
                                                print("Start Date ",startdate)
                                                print("End Date ",enddate)
                                                suppression_start = str((servernextpatchtime + timedelta(minutes=1)))
                                                suppression_end = str((serverendpatchtime - timedelta(minutes=1)))
                                                servertransferdetails.update({"servername":ivanti_server, "start_date":startdate, "end_date":enddate, "expected_start":startdate, "shortdescription":shortdescription, "description":shortdescription})
                                               
                                                ###### adding change creation part ######                               
                                                test_plan="""Verify system availability 
Verify successful patch installation
Generate Patch compliance report
Turn over server to POC for application validation"""
                                                description = """What is this change for?
This change is the regularly scheduled compliance patching of this server
This change was approved under the parent change Nucleus Patching Automation ("""+ companyname +""" -"""+ os_type + """) and (PROD Servers)The server will be unavailable during the restart of the server.
This change is scheduled during the approved patching window
Patch Scan File Name: """ + file_name + """
Machine Group Name: """ + machine_group_name 
                                                backout_plan = """In the event that a system or application becomes unavailable, the offending patch will be uninstalled. If uninstalling the patch does not restore services, the server will be restored from backup following documented DR plans."""
                                                work_notes = 'This is a change created with automation'
                                                change_plan = description
                                                payload = {
                                                    'start_date': startdate,
                                                    'state': 1,
                                                    'assigned_to': self.sn_username,
                                                    'assignment_group': assignment_group,
                                                    'backout_plan': backout_plan,
                                                    'category': 'Perform',
                                                    'change_plan': change_plan,
                                                    'cmdb_ci': ivanti_server,
                                                    'company': companyname,
                                                    'contact_type': 'email',
                                                    'end_date': enddate,
                                                    'expected_start': startdate,
                                                    'implementation_plan': 'Test',
                                                    'justification': 'justification',
                                                    'risk': 4,
                                                    'test_plan': test_plan,
                                                    'type': "Normal",
                                                    'u_change_management_group': change_management_group,
                                                    'work_notes': work_notes,
                                                    'short_description': shortdescription,
                                                    'description': description,
                                                    'approval': 'approved',
                                                    'u_req_by_email': req_by_email,
                                                    'impact': 3,
                                                    'u_change_environment': 'Production',
                                                    'u_subcategory': 'Restart Scheduled Maintenance',
                                                    'u_is_incident_suppression_requ': 'true',
                                                    'u_change_reason': 'Maintenance',
                                                    'u_suppression_start': suppression_start,
                                                    'u_suppression_end': suppression_end,
                                                    'u_validation_time': '00:20:00',
                                                    'u_backout_time': '00:00:10',
                                                    'u_implementation_time': '00:30:00',
                                                    'u_total_change_time': '01:00:00',
                                                    'location': 'Location Not Provided',
                                                    'u_locations': 'Location Not Provided',
                                                    'u_approvers': 'Integration Approver',
                                                    'requested_by': self.sn_username
                                                }
                                                #endpoint =  '/api/now/table/change_request'
                                                endpoint = '/api/ntt11/changestackstormautomation/create_change'
                                                url = self.config['servicenow']['url']
                                                self.sn_username = self.config['servicenow']['username']
                                                self.sn_password = self.config['servicenow']['password']
                                                sn_url = "https://{0}{1}".format(url, endpoint)
                                                headers = {'Content-type': 'application/json','Accept': 'application/json'}
                                                #method= 'POST'
                                                createdchangenumber = ''
                                                change = requests.request("POST",sn_url, auth=HTTPBasicAuth(self.sn_username, self.sn_password), json=payload, headers=headers, verify=False)  
                                                #change = self.sn_api_call('POST', endpoint, payload=payload)
                                                change = change.json()
                                                createdchangemessage = change['result']['message']
                                                #print(createdchangemessage)
                                                createdchangenumber = createdchangemessage.split(':')[1].strip().split(' ')[0].strip()
                                                #createdchangenumber = change["number"]["value"]
                                                #createdchangeid = change["sys_id"]["value"]
                                                print(createdchangenumber)
                                    
                                                update_endpoint = '/api/ntt11/v1/chg_mgmt/UpdateChange'
                                                payload = {
                                                    "number": createdchangenumber,
                                                    "company": companyname,
                                                    "u_change_management_group": change_management_group
                                                }
                                                response = self.sn_api_call('POST', update_endpoint, payload=payload)
                                                #update_endpoint = "https://{0}{1}".format(url, update_endpoint)
                                                #response = requests.request("POST",update_endpoint, auth=HTTPBasicAuth(self.sn_username, self.sn_password), json=payload, headers=headers, verify=False)
                                                sleep(2)
                                                   
                                                #First step of change approval Request
                                                endpoint1 = '/api/dems/ebonding_change_automation/changeAutomation'
                                                payload1 = {"company":companyname,"number":createdchangenumber,"request_approval":"Yes"}
                                                change1 = self.sn_api_call('POST', endpoint1, payload=payload1)
                                                sleep(10)
                                    
                                                # Second Step of change approval
                                                endpoint2 = '/api/dems/ebonding_change_automation/changeAutomation'
                                                payload2 = {"company":companyname,"number":createdchangenumber,"approval":"Approve"}
                                                change2 = self.sn_api_call('POST', endpoint2, payload=payload2)
                                                sleep(10)

                                                # Next step of change approval Request
                                                endpoint3 = '/api/dems/ebonding_change_automation/changeAutomation'
                                                payload3 = {"company":companyname,"number":createdchangenumber,"request_approval":"Yes"}
                                                change3 = self.sn_api_call('POST', endpoint3, payload=payload3)
                                                sleep(10)

                                                # Next Step of change approval
                                                endpoint4 = '/api/dems/ebonding_change_automation/changeAutomation'
                                                payload4 = {"company":companyname,"number":createdchangenumber,"approval":"Approve"}
                                                change4 = self.sn_api_call('POST', endpoint4, payload=payload4)
                                                sleep(10)
                                    
                                                # Next Step of change approval    
                                                endpoint5 = '/api/dems/ebonding_change_automation/changeAutomation'
                                                payload5 = {"company":companyname,"number":createdchangenumber,"approval":"Approve"}
                                                change5 = self.sn_api_call('POST', endpoint5, payload=payload5)

                                                changenumberandserver = createdchangenumber + " : " + servername
                                                changescreated.append(changenumberandserver)
                                                print("changescreated value",changescreated)
                                                ######## end of change creation ##########
                                                print(servertransferdetails)
                                    
                                            elif serverbooleanresult == 0 and serverconnectivityresult == 1:
                                                print(" --------------- Server not found in CMDB ----------------")
                                                print(servernotincmdb , serverconnectivityresult, "{} not in CMDB".format(servername))
                                                servernotincmdbformat = '('+ servername +') not in operational status for ('+companyname+')'
                                                servernotincmdb.append(servernotincmdbformat)
                                            elif serverconnectivityresult == 0 and serverbooleanresult == 1:
                                                print(" --------------- Server Connectivity Failed .----------------")
                                                print(servernotincmdb , serverconnectivityresult, "{} connectivity issue".format(servername))
                                                serverconnectivityfailed = serverconnectivityfailed
                                            else:
                                                print("---------------- Server is neither Connected nor found in CMDB ----------------")
                                                print(servernotincmdb , serverconnectivityresult, "Both failed for server {}".format(servername))
                                                servernotincmdbformat = '('+ servername +') not in operational status for ('+companyname+')'
                                                servernotincmdb.append(servernotincmdbformat)
                                                serverconnectivityfailed = serverconnectivityfailed
                                        if servertransferdetails:
                                            transferdetails.append(servertransferdetails)
                                        
                                        print(len(changescreated),len(servernotincmdb),len(serverconnectivityfailed))
                                        if len(changescreated) > 0:
                                            messagebody = """
Nucleus Patching Automation Change Creation: All changes created for ("""+ companyname +""" - Windows) group ("""+ machine_group_name +""")
Changes created: """+ str(len(changescreated)) +"""
"""+ '\n'.join(changescreated) +"""
This automated message was sent to you at: """ + str((datetime.now()).astimezone(pytz.timezone('GMT'))) + """."""
                                            subject = "Nucleus Patching Automation Change Creation: All changes created for ('+ companyname +' - Windows) group ('+ machine_group_name+')"
                                            url = "https://api.sendgrid.com/v3/mail/send"
                                            payload = json.dumps({"personalizations": [{"to": [{"email": "Sreedevi.AN@nttdata.com"}]}],"from": {"email": "noreply@nttdso.net"},"subject": subject,"content": [{"type": "text/plain","value": messagebody}]})
                                            headers = {'Content-Type': 'application/json','Authorization': 'Bearer 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'}
                                            #print(payload)
                                            try:
                                                print("Inside change creation mail")
                                                response = requests.request("POST", url, headers=headers, data=payload)
                                            except Exception as e:
                                                print("An error occured : "+ str(e))
                                        else:
                                            print("No changes created in this group: ", machine_group_name)

                                        servernotincmdb = []
                                        changescreated = []
                                        nopatch_servers = []
                                        serverconnectivityfailed=[]
                                        print(servervalidate)
                                        results = {"servers_data":transferdetails}    
                                             
                                else:
                                    print("Schedule Time is changed")
                                    reschedule_endpoint = '/api/ntt11/changestackstormautomation/update_change'
                                    sn_url = "https://{0}{1}".format(url,reschedule_endpoint)
                                    headers = {'Content-type': 'application/json','Accept': 'application/json'}
                                    print(startdate)
                                    print(enddate)
                                    # Update Change
                                    method = "POST"
                                    endpoint = "/api/ntt11/changestackstormautomation/update_change"
                                    #endpoint = '/api/now/table/change_request/'+ change_sys_id
                                    payload = {
                                        'number': change_id,
                                        'company': companyname,
                                        'work_notes': 'Rescheduling the Change as per the updated Scan file',
                                        'start_date': startdate,
                                        'end_date': enddate,
                                        'expected_start': startdate,
                                        'u_is_incident_suppression_requ': 'false',
                                        #'u_suppression_start': '2025-07-17 14:25:00', 
                                        #'u_suppression_end': '2025-07-17 15:20:00',
                                        #'u_suppression_start': suppression_start,
                                        #'u_suppression_end': suppression_end,
                                        'u_validation_time': '00:20:00',
                                        'u_backout_time': '00:10:00',
                                        'u_implementation_time': '00:30:00',
                                        'u_total_change_time': '01:00:00',
                                    }
                                    #print(payload)
                                    update_change_request = self.sn_api_call('POST', endpoint, payload=payload)
                                    #response1 = requests.request('POST',sn_url, auth=HTTPBasicAuth(self.sn_username, self.sn_password), json=payload, headers=headers, verify=False)
                                    #response1 = self.sn_api_call('POST', reschedule_endpoint, payload=payload)
                                    #print(response1.json())
                                    print(update_change_request)   
                        except ET.ParseError as e:
                            print("Error: {e}")                
                    
            else:
                if scan_file_exists == 0:
                    print("No Scanfile Found.Cancelling the Change - ",change_id)
                    #endpoint = '/api/ntt11/changestackstormautomation/update_change'
                    #endpoint = '/api/now/table/change_request/' + change_sys_id
                    endpoint = '/api/ntt11/changestackstormautomation/cancel_change'
                    url = self.config['servicenow']['url']
                    self.sn_username = self.config['servicenow']['username']
                    self.sn_password = self.config['servicenow']['password']
                    sn_url = "https://{0}{1}".format(url, endpoint)
                    #suppression_start = (planned_start_date + timedelta(minutes=1))
                    #suppression_end = (planned_end_date - timedelta(minutes=1))
                    headers = {'Content-type': 'application/json','Accept': 'application/json'}
                    payload = {
                        'number': change_id,
                        'state': '9',
                        'company': companyname,
                        #'u_is_incident_suppression_requ': 'false',
                        #"u_suppression_start': "2025-07-17 15:35:00",
                        #"u_suppression_end': "2025-07-17 16:00:00",
                        #'start_date': planned_start_date,
                        #'end_date': planned_end_date,
                        'u_cancel_reason': 'No Longer Required',
                        #'u_validation_time': '00:20:00',
                        #'u_backout_time': '00:00:10',
                        #'u_implementation_time': '00:30:00',
                        #'u_total_change_time': '01:00:00',
                        #'cmdb_ci': 'AUTOMATION'
                    }
                    print(payload)
                    #response2 = self.sn_api_call('PATCH', endpoint, payload=payload)
                    #return response2
                    #cancel_change_request = self.sn_api_call('PATCH', endpoint, payload=payload)
                    cancel_change_request = requests.request("POST",sn_url, auth=HTTPBasicAuth(self.sn_username, self.sn_password), json=payload, headers=headers, verify=False)
                    print(cancel_change_request.json())
